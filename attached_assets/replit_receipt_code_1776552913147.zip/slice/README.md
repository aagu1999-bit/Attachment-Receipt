# Slice

> Upload a receipt, share a link, tap what you ate. Slice does the math.

Slice is an item-aware collaborative bill-splitting webapp. One person (the payer) uploads a receipt; the OCR API extracts line items, tax, tip and fees; friends join a shared URL and each person taps the specific items they ordered — including partial shares of multi-quantity items (e.g. 2 of 6 Guinness pints). Selections stream in real-time over WebSockets. When the host finalizes, Slice splits fees evenly and food costs per-claimant, down to the cent.

## File tree

```
slice/
├── backend/
│   ├── main.py            FastAPI + python-socketio server, REST + ws routes
│   ├── database.py        SQLite schema + connection helpers
│   ├── models.py          Pydantic request / response schemas
│   ├── ocr_service.py     Mindee / Veryfi / stub OCR adapters
│   ├── calculator.py      Pure splitting algorithm (integer cents)
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── index.html         SPA shell, Tailwind via CDN
│   ├── css/styles.css     Editorial paper-aesthetic overrides
│   └── js/
│       ├── api.js         fetch() wrapper → backend REST
│       ├── socket.js      Socket.IO client wrapper
│       ├── views.js       Pure render functions for each route
│       └── app.js         Hash router + state + event wiring
├── SPEC.md                Full technical specification
└── README.md              (you are here)
```

## Quick start

```bash
# 1. Install backend deps
cd backend
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2. Configure OCR (optional — omit to use the stub for dev)
cp .env.example .env
#   then open .env and paste your MINDEE_API_KEY
#   (sign up free at https://platform.mindee.com/)

# 3. Run the server (serves both API and frontend)
uvicorn main:socket_app --reload --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000/` and you're in. If you haven't added a Mindee key, the app falls back to a deterministic stub receipt so you can exercise the full flow offline.

## The user flow, end to end

1. **Host** lands on `/`, clicks *Start a new receipt*, enters their name → session created.
2. **Host** uploads an image → Mindee parses it → host reviews / edits the line items, tax, tip, fees.
3. **Host** clicks *Start collaborative session* → session flips to `open`, share URL is the current location.
4. **Friends** open the link, enter a name, then see the live item list. Multi-quantity items show `−/+` counters bounded by what's still available.
5. Every selection fires a `session:update` broadcast so everyone's UI stays in sync.
6. Each participant clicks *Submit my share*.
7. **Host** clicks *Finalize bill* → server runs the split, everyone is auto-navigated to the results screen with a "who owes whom" breakdown.

## The math

For every finalization:

```
N           = number of participants
fees_total  = tax + tip + other_fees
fees_pp     = fees_total ÷ N                  (evenly split)
food_p      = Σ (quantity_selected × unit_price)   (per person)
total_p     = food_p + fees_pp
```

Done in integer cents, with remainder-reconciliation so `Σ total_p` equals the actual bill to the cent. See `backend/calculator.py`.

## Swapping OCR providers

Set `OCR_PROVIDER` in `.env`:

- `mindee` — Mindee Receipt v5 (default)
- `veryfi` — Veryfi Documents API
- `stub`   — deterministic fake, no network

Each adapter normalises to the same output dict, so the rest of the system is provider-agnostic. See `backend/ocr_service.py` to add a new one.

## Production notes

This codebase is deliberately dev-grade. Before shipping publicly you'd want:
- A real auth tier (signed session tokens rather than UUIDs in localStorage)
- Rate limits on `/upload`
- A session janitor (TTL-based cleanup)
- A narrower CORS origin list

Full details live in `SPEC.md § 10`.

## License

MIT (or your preferred license — add a LICENSE file before distributing).
