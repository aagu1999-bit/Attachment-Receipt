# Slice — Technical Specification

**Version 1.0** · Collaborative, item-aware bill splitting

---

## 1. Goals & non-goals

**Goals.** Let a payer upload a restaurant receipt once, invite friends to a shared session via URL, have each friend claim exactly the items they had (including multi-quantity items like "6 Guinness"), then compute a provably-correct split that covers tax, tip, and other fees evenly while charging food costs per-claimant.

**Non-goals.** Payment integration (Venmo/PayPal), OCR we train ourselves (we consume a commercial API), mobile-native apps, multi-payer settlements, currency conversion.

---

## 2. Architecture

```
  ┌─────────────────┐        HTTPS JSON        ┌──────────────────────┐
  │  Vanilla JS SPA │ ───────────────────────▶ │  FastAPI + SocketIO  │
  │  (hash routing) │ ◀──── Socket.IO (ws) ─── │  (ASGI, uvicorn)     │
  └─────────────────┘                          ├──────────────────────┤
                                               │ ocr_service.py       │──▶ Mindee / Veryfi
                                               ├──────────────────────┤
                                               │ calculator.py (pure) │
                                               ├──────────────────────┤
                                               │ SQLite  (WAL, FK=ON) │
                                               └──────────────────────┘
```

- **Single process.** FastAPI serves REST, Socket.IO, and the static SPA on one port. Fine for dev, trivially containerisable.
- **State lives server-side.** The client keeps only `{participant_id, name, is_host}` per session in `localStorage` — that's the auth token for subsequent actions.
- **Money is integer cents on the server**, dollar floats over the wire.

---

## 3. Data model (SQLite)

| Table           | Key        | Purpose                                                            |
|-----------------|------------|--------------------------------------------------------------------|
| `sessions`      | id (uuid)  | One per bill. Holds merchant, tax/tip/fees in cents, status.       |
| `participants`  | id (uuid)  | Host + friends. `is_host`, `submitted` flags.                      |
| `receipt_items` | id (uuid)  | Parsed line items: name, `unit_price_cents`, `quantity`, position. |
| `selections`    | id (uuid)  | `(participant, item, quantity)`. UNIQUE on (participant, item).    |

`status` progresses `draft → open → finalized`. FK cascades drop a session's children on deletion.

---

## 4. Session state machine

```
  draft       (host is editing OCR output)
    │  host POSTs /review
    ▼
  open        (participants joining & selecting)
    │  host POSTs /finalize
    ▼
  finalized   (read-only; /results is the source of truth)
```

Guards enforced in the route layer:

- Uploads accepted only while `draft`.
- Joins and selections accepted only while `open`.
- Only the recorded host participant may `/finalize`.
- Already-submitted participants may not modify their selections without un-submitting first.

---

## 5. REST API

All request/response bodies are JSON. Money in responses is dollars (float, 2dp).

| Method | Path                                                   | Purpose                       |
|--------|--------------------------------------------------------|-------------------------------|
| POST   | `/api/sessions`                                        | Create session + host         |
| POST   | `/api/sessions/{sid}/upload` *(multipart)*             | OCR an uploaded receipt       |
| POST   | `/api/sessions/{sid}/review`                           | Persist host-edited receipt   |
| GET    | `/api/sessions/{sid}`                                  | Full current state            |
| POST   | `/api/sessions/{sid}/join`                             | Non-host joins                |
| POST   | `/api/sessions/{sid}/participants/{pid}/select`        | Upsert a selection            |
| POST   | `/api/sessions/{sid}/participants/{pid}/submit`        | Lock your share               |
| POST   | `/api/sessions/{sid}/participants/{pid}/unsubmit`      | Undo submit                   |
| POST   | `/api/sessions/{sid}/finalize` *(form: participant_id)*| Lock and compute              |
| GET    | `/api/sessions/{sid}/results`                          | Final split                   |

Error format: `{"detail": "human-readable string"}` with a conventional HTTP status (400 client error, 403 host-only, 404 not found, 409 invariant broken).

---

## 6. Real-time layer

Socket.IO 4.x, ASGI-mounted under `/socket.io`. Minimal protocol:

| Event               | Direction | Payload                              |
|---------------------|-----------|--------------------------------------|
| `join`              | C → S     | `{session_id, participant_id}`       |
| `session:update`    | S → C     | Full `SessionOut` object             |
| `session:finalized` | S → C     | `FinalResults` object                |

`session:update` is emitted by the server after every mutating REST call — selections, joins, submits, reviews. The client treats the broadcast as authoritative and re-renders.

> Why broadcast the whole session rather than deltas? The payload is small (one bill, ≤20 items, ≤15 people), state reconciliation is trivial, and it eliminates whole classes of bug.

---

## 7. The splitting algorithm

Implemented in `backend/calculator.py` exactly per spec:

```
N           = |participants|
fees_total  = tax + tip + other_fees                     (all in cents)
fees_pp     = fees_total // N                            (integer cents)
residue     = fees_total - fees_pp * N                   (0 ≤ residue < N)
# the first `residue` participants (by join order) each absorb one extra cent

food_p      = Σ qty_selected_i * unit_price_i            (per participant)
total_p     = food_p + fees_share_p
```

**Penny reconciliation.** The residue distribution guarantees `Σ total_p ≡ bill_total` to the cent — no rounding drift is ever lost or invented.

**Edge cases.**

- `N = 0` → no summaries, zero-filled payload.
- `N = 1` → sole participant owes the full bill.
- Unclaimed items → they *still cost money* but nobody is paying for them. The UI surfaces this as `claimed-pill--empty`. Hosts can insist someone claim them before finalizing.

**Settlement graph.** Star topology — every non-host settles directly with the host. A full minimum-transactions solver (Splitwise-style) is unnecessary here because there's a single payer by design.

---

## 8. OCR integration

`ocr_service.py` exposes one async entry point:

```python
async def parse_receipt(image_bytes: bytes, filename: str) -> dict: ...
```

The provider is selected by the `OCR_PROVIDER` environment variable: `mindee` (default), `veryfi`, or `stub`. The stub returns a deterministic synthetic receipt — useful for development without burning API credits and essential for CI.

**Output contract** (stable across providers):

```python
{
  "merchant": str,
  "items":    [{"name": str, "unit_price": float, "quantity": int, "line_total": float}],
  "tax":      float,
  "tip":      float,
  "fees":     float,    # non-food surcharges / admin
  "currency": str,
}
```

Mindee's v5 Receipt API doesn't expose a discrete "other fees" bucket, so we derive it as `total - subtotal - tax - tip` and clamp to ≥ 0. The host can always edit the result before confirming.

---

## 9. Validation & invariants

1. **Quantity invariant.** `Σ selections[item] ≤ item.quantity` is enforced in `calculator.can_select()` and checked server-side on every selection. Clients mirror the invariant visually (`+` button disabled), but the server is authoritative.
2. **Host-only finalize.** `sessions.host_participant_id` must match the caller. 403 otherwise.
3. **Item editing is a session-draft operation only.** Once `status='open'`, items are immutable (prevents the host from changing the menu out from under active claimants).
4. **Non-negative money.** Pydantic `ge=0` on all money fields.
5. **Submitted participants are read-only.** Must un-submit to edit.

---

## 10. Security posture

This is a dev-grade implementation. For production you should add:

- Rate-limiting on `/upload` (OCR is expensive).
- Participant auth tokens (HMAC-signed) instead of plain UUIDs in localStorage.
- CORS origin allowlist (currently `*`).
- Receipt image retention policy — the current code doesn't persist uploads; they live in memory only during OCR.
- Session TTL / janitor (expire after 30 days).
- CAPTCHA or proof-of-work on session creation.

---

## 11. Testing strategy (suggested)

- **Unit** — `calculator.split_bill()` with table-driven cases covering N=0, N=1, residue distribution, unclaimed items, multi-qty items.
- **Unit** — `can_select()` exhaustive boundary table.
- **Integration** — end-to-end flow using the stub OCR provider: create → upload → review → join (×2) → select → submit → finalize → results. Assert `Σ totals == grand_total`.
- **Socket** — two concurrent clients; one selects, other sees `session:update` within 500ms.
