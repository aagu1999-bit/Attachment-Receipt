/* ---------------------------------------------------------------- *
 *  api.js — tiny fetch wrapper. Exposes window.SliceAPI.
 *  All money values travel as dollar floats.
 * ---------------------------------------------------------------- */

(function () {
    'use strict';

    const BASE = '';  // same-origin

    async function request(path, opts = {}) {
        const init = { method: opts.method || 'GET', headers: {} };

        if (opts.json !== undefined) {
            init.headers['Content-Type'] = 'application/json';
            init.body = JSON.stringify(opts.json);
        } else if (opts.form !== undefined) {
            init.body = opts.form;  // FormData; let browser set boundary
        }

        let resp;
        try {
            resp = await fetch(BASE + path, init);
        } catch (err) {
            throw new Error('Network error: ' + err.message);
        }

        const text = await resp.text();
        const data = text ? safeJson(text) : null;

        if (!resp.ok) {
            const detail = (data && data.detail) || resp.statusText || 'Request failed';
            const e = new Error(detail);
            e.status = resp.status;
            throw e;
        }
        return data;
    }

    function safeJson(text) {
        try { return JSON.parse(text); } catch { return { raw: text }; }
    }

    const SliceAPI = {
        createSession: (hostName) =>
            request('/api/sessions', { method: 'POST', json: { host_name: hostName } }),

        uploadReceipt: (sessionId, file) => {
            const fd = new FormData();
            fd.append('file', file);
            return request(`/api/sessions/${sessionId}/upload`, { method: 'POST', form: fd });
        },

        reviewReceipt: (sessionId, payload) =>
            request(`/api/sessions/${sessionId}/review`, { method: 'POST', json: payload }),

        getSession: (sessionId) =>
            request(`/api/sessions/${sessionId}`),

        joinSession: (sessionId, name) =>
            request(`/api/sessions/${sessionId}/join`, { method: 'POST', json: { name } }),

        setSelection: (sessionId, participantId, itemId, quantity) =>
            request(`/api/sessions/${sessionId}/participants/${participantId}/select`,
                { method: 'POST', json: { item_id: itemId, quantity } }),

        submitShare: (sessionId, participantId) =>
            request(`/api/sessions/${sessionId}/participants/${participantId}/submit`,
                { method: 'POST' }),

        unsubmitShare: (sessionId, participantId) =>
            request(`/api/sessions/${sessionId}/participants/${participantId}/unsubmit`,
                { method: 'POST' }),

        finalize: (sessionId, participantId) => {
            const fd = new FormData();
            fd.append('participant_id', participantId);
            return request(`/api/sessions/${sessionId}/finalize`,
                { method: 'POST', form: fd });
        },

        getResults: (sessionId) =>
            request(`/api/sessions/${sessionId}/results`),
    };

    window.SliceAPI = SliceAPI;
})();
