/* ---------------------------------------------------------------- *
 *  app.js — SPA controller.
 *
 *  Responsibilities:
 *      - hash-based routing  (#/ ,  #/host/new , #/host/:id/upload ,
 *                              #/host/:id/review , #/session/:id , #/session/:id/done)
 *      - local state  (participant_id per session, stored in localStorage)
 *      - event wiring for each rendered view
 *      - socket fan-out into re-renders
 *
 *  No frameworks. Everything is deliberately explicit.
 * ---------------------------------------------------------------- */

(function () {
    'use strict';

    const app = document.getElementById('app');
    const toastRegion = document.getElementById('toast-region');

    // ------------- tiny local-storage wrapper ------------- //
    const storage = {
        key: (sessionId) => `slice:session:${sessionId}`,
        getMe(sessionId) {
            try { return JSON.parse(localStorage.getItem(this.key(sessionId)) || 'null'); }
            catch { return null; }
        },
        setMe(sessionId, data) {
            localStorage.setItem(this.key(sessionId), JSON.stringify(data));
        },
    };

    // ------------- toast ------------- //
    function toast(msg, kind = '') {
        const el = document.createElement('div');
        el.className = 'toast' + (kind ? ` toast--${kind}` : '');
        el.textContent = msg;
        toastRegion.appendChild(el);
        setTimeout(() => {
            el.style.transition = 'opacity 200ms ease';
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 220);
        }, 2600);
    }

    // ------------- mount helper ------------- //
    function mount(node) {
        app.innerHTML = '';
        app.appendChild(node);
    }

    // ------------- OCR transient store (between /upload and /review) ------------- //
    // We stash the OCR response in memory keyed by session id so a refresh after
    // upload simply re-does OCR — cheaper than persisting a half-filled draft.
    const ocrDraft = {};

    // =================================================================
    //  ROUTER
    // =================================================================
    const routes = [
        { pattern: /^#\/?$/,                                           handler: showHome },
        { pattern: /^#\/host\/new$/,                                   handler: showHostStart },
        { pattern: /^#\/host\/([^/]+)\/upload$/,                       handler: showHostUpload },
        { pattern: /^#\/host\/([^/]+)\/review$/,                       handler: showHostReview },
        { pattern: /^#\/session\/([^/]+)$/,                            handler: showSession },
        { pattern: /^#\/session\/([^/]+)\/done$/,                      handler: showResults },
    ];

    function route() {
        const hash = window.location.hash || '#/';
        for (const r of routes) {
            const m = hash.match(r.pattern);
            if (m) {
                try { return r.handler(...m.slice(1)); }
                catch (err) {
                    console.error(err);
                    mount(SliceViews.renderError(err));
                    return;
                }
            }
        }
        mount(SliceViews.renderError(new Error('Route not found: ' + hash)));
    }

    // Clean up socket listeners on route change so old views don't react.
    let currentOnSocketUpdate = null;
    let currentOnSocketFinalized = null;

    function resetSocketHandlers() {
        if (currentOnSocketUpdate)    SliceSocket.off('session:update',    currentOnSocketUpdate);
        if (currentOnSocketFinalized) SliceSocket.off('session:finalized', currentOnSocketFinalized);
        currentOnSocketUpdate = null;
        currentOnSocketFinalized = null;
    }

    // Intercept data-link clicks for smooth hash navigation
    document.addEventListener('click', (e) => {
        const a = e.target.closest('a[data-link]');
        if (!a) return;
        const href = a.getAttribute('href');
        if (href && href.startsWith('#')) {
            e.preventDefault();
            if (window.location.hash === href) route();
            else window.location.hash = href;
        }
    });

    window.addEventListener('hashchange', () => { resetSocketHandlers(); route(); });

    // =================================================================
    //  VIEW: HOME
    // =================================================================
    function showHome() {
        const node = SliceViews.renderHome();
        mount(node);

        node.querySelector('#btn-start').addEventListener('click', () => {
            window.location.hash = '#/host/new';
        });
        const joinForm = node.querySelector('#join-form');
        node.querySelector('#btn-join').addEventListener('click', () => {
            joinForm.classList.toggle('hidden');
            if (!joinForm.classList.contains('hidden'))
                joinForm.querySelector('#join-code').focus();
        });
        node.querySelector('#btn-join-go').addEventListener('click', () => {
            const code = node.querySelector('#join-code').value.trim();
            if (!code) { toast('Enter a session id', 'error'); return; }
            window.location.hash = `#/session/${encodeURIComponent(code)}`;
        });
    }

    // =================================================================
    //  VIEW: HOST — NAME ENTRY
    // =================================================================
    function showHostStart() {
        const node = SliceViews.renderHostStart();
        mount(node);
        const input = node.querySelector('#host-name');
        input.focus();
        const submit = async () => {
            const name = input.value.trim();
            if (!name) { toast('Pop your name in first', 'error'); return; }
            try {
                const { session_id, participant_id } = await SliceAPI.createSession(name);
                storage.setMe(session_id, { participant_id, name, is_host: true });
                window.location.hash = `#/host/${session_id}/upload`;
            } catch (e) { toast(e.message, 'error'); }
        };
        node.querySelector('#host-continue').addEventListener('click', submit);
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
    }

    // =================================================================
    //  VIEW: HOST — UPLOAD
    // =================================================================
    function showHostUpload(sessionId) {
        const me = storage.getMe(sessionId);
        if (!me || !me.is_host) {
            // someone hit this URL without being the host — kick them to join flow
            window.location.hash = `#/session/${sessionId}`;
            return;
        }
        const node = SliceViews.renderHostUpload(sessionId);
        mount(node);

        const dz = node.querySelector('#dropzone');
        const input = node.querySelector('#file-input');
        const status = node.querySelector('#upload-status');

        dz.addEventListener('click', () => input.click());
        dz.addEventListener('dragover', (e) => { e.preventDefault(); dz.classList.add('dropzone--hover'); });
        dz.addEventListener('dragleave', () => dz.classList.remove('dropzone--hover'));
        dz.addEventListener('drop', (e) => {
            e.preventDefault();
            dz.classList.remove('dropzone--hover');
            if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
        });
        input.addEventListener('change', (e) => {
            if (e.target.files[0]) handleFile(e.target.files[0]);
        });

        async function handleFile(file) {
            status.innerHTML = '<span class="spinner"></span> &nbsp; Parsing receipt — this takes a few seconds…';
            try {
                const parsed = await SliceAPI.uploadReceipt(sessionId, file);
                ocrDraft[sessionId] = parsed;
                window.location.hash = `#/host/${sessionId}/review`;
            } catch (e) {
                status.textContent = '';
                toast(e.message, 'error');
            }
        }
    }

    // =================================================================
    //  VIEW: HOST — REVIEW
    // =================================================================
    function showHostReview(sessionId) {
        const me = storage.getMe(sessionId);
        if (!me || !me.is_host) {
            window.location.hash = `#/session/${sessionId}`;
            return;
        }
        const parsed = ocrDraft[sessionId];
        if (!parsed) {
            // lost the draft on refresh — bounce back to upload
            window.location.hash = `#/host/${sessionId}/upload`;
            return;
        }

        const node = SliceViews.renderHostReview(parsed, sessionId);
        mount(node);

        const itemsList = node.querySelector('#items-list');

        function recomputeTotals() {
            let subtotal = 0;
            itemsList.querySelectorAll('[data-item-row]').forEach(row => {
                const p = parseFloat(row.querySelector('[data-field="unit_price"]').value) || 0;
                const q = parseInt(row.querySelector('[data-field="quantity"]').value, 10) || 0;
                subtotal += p * q;
            });
            const tax  = parseFloat(node.querySelector('#tax').value)  || 0;
            const tip  = parseFloat(node.querySelector('#tip').value)  || 0;
            const fees = parseFloat(node.querySelector('#fees').value) || 0;
            const total = subtotal + tax + tip + fees;
            node.querySelector('#subtotal-out').textContent =
                subtotal.toLocaleString(undefined, { style: 'currency', currency: 'USD' });
            node.querySelector('#total-out').textContent =
                total.toLocaleString(undefined, { style: 'currency', currency: 'USD' });
        }

        // live total on any input
        node.addEventListener('input', recomputeTotals);

        // remove item
        node.addEventListener('click', (e) => {
            const rm = e.target.closest('[data-remove]');
            if (rm) { rm.closest('[data-item-row]').remove(); recomputeTotals(); }
        });

        // add missing item
        node.querySelector('#add-item').addEventListener('click', () => {
            const idx = itemsList.children.length;
            const row = document.createElement('div');
            row.className = 'grid grid-cols-12 gap-2 items-center py-2 border-b border-ink/10';
            row.setAttribute('data-item-row', '');
            row.setAttribute('data-idx', idx);
            row.innerHTML = `
                <input class="col-span-6 bg-paper border border-ink/15 rounded px-2 py-1.5 text-sm" data-field="name" placeholder="Item name" />
                <input class="col-span-2 bg-paper border border-ink/15 rounded px-2 py-1.5 text-sm font-mono" data-field="unit_price" type="number" step="0.01" min="0" value="0.00" />
                <input class="col-span-2 bg-paper border border-ink/15 rounded px-2 py-1.5 text-sm font-mono" data-field="quantity"   type="number" step="1"    min="1" value="1" />
                <button class="col-span-2 text-xs text-rust hover:underline justify-self-end" data-remove>remove</button>`;
            itemsList.appendChild(row);
            row.querySelector('[data-field="name"]').focus();
            recomputeTotals();
        });

        recomputeTotals();

        // finalize review -> POST /review -> navigate to session
        node.querySelector('#start-session').addEventListener('click', async () => {
            const items = [];
            let bad = false;
            itemsList.querySelectorAll('[data-item-row]').forEach(row => {
                const name = row.querySelector('[data-field="name"]').value.trim();
                const price = parseFloat(row.querySelector('[data-field="unit_price"]').value);
                const qty   = parseInt(row.querySelector('[data-field="quantity"]').value, 10);
                if (!name) { bad = true; return; }
                if (isNaN(price) || price < 0) { bad = true; return; }
                if (isNaN(qty) || qty < 1) { bad = true; return; }
                items.push({ name, unit_price: price, quantity: qty });
            });
            if (bad || items.length === 0) {
                toast('Every item needs a name, a non-negative price, and qty ≥ 1', 'error');
                return;
            }
            const payload = {
                merchant: node.querySelector('#merchant').value.trim(),
                tax:   parseFloat(node.querySelector('#tax').value)  || 0,
                tip:   parseFloat(node.querySelector('#tip').value)  || 0,
                fees:  parseFloat(node.querySelector('#fees').value) || 0,
                items,
            };
            try {
                await SliceAPI.reviewReceipt(sessionId, payload);
                delete ocrDraft[sessionId];
                window.location.hash = `#/session/${sessionId}`;
            } catch (e) { toast(e.message, 'error'); }
        });
    }

    // =================================================================
    //  VIEW: SESSION (the live collaborative room)
    // =================================================================
    async function showSession(sessionId) {
        mount(SliceViews.renderLoading('Opening session…'));

        let session;
        try { session = await SliceAPI.getSession(sessionId); }
        catch (e) { mount(SliceViews.renderError(e)); return; }

        // If finalized, skip to results.
        if (session.status === 'finalized') {
            window.location.hash = `#/session/${sessionId}/done`;
            return;
        }

        let me = storage.getMe(sessionId);

        // Host who arrived here directly but hasn't uploaded yet -> send to upload step.
        if (me && me.is_host && session.status === 'draft') {
            window.location.hash = `#/host/${sessionId}/upload`;
            return;
        }

        // Non-host arriving while session is still in draft -> waiting screen.
        if (!me && session.status === 'draft') {
            mount(SliceViews.renderWaitingForHost(session));
            // Poll every 2s until host flips it to 'open'. Cheap enough for this.
            const poll = setInterval(async () => {
                try {
                    const fresh = await SliceAPI.getSession(sessionId);
                    if (fresh.status !== 'draft') {
                        clearInterval(poll);
                        route();  // re-run showSession on the same hash
                    }
                } catch (_) { clearInterval(poll); }
            }, 2000);
            return;
        }

        // Nobody in localStorage yet -> show join form.
        if (!me) {
            const joinNode = SliceViews.renderJoin(sessionId, session);
            mount(joinNode);
            const input = joinNode.querySelector('#join-name');
            input.focus();
            const go = async () => {
                const name = input.value.trim();
                if (!name) { toast('Name required', 'error'); return; }
                try {
                    const { participant_id } = await SliceAPI.joinSession(sessionId, name);
                    storage.setMe(sessionId, { participant_id, name, is_host: false });
                    route();
                } catch (e) { toast(e.message, 'error'); }
            };
            joinNode.querySelector('#join-continue').addEventListener('click', go);
            input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
            return;
        }

        // Happy path — render the live room and wire sockets.
        renderRoom(session, me);
        SliceSocket.connect(sessionId, me.participant_id);

        currentOnSocketUpdate = (fresh) => {
            // If the server tells us we've been finalized, jump to results.
            if (fresh.status === 'finalized') {
                window.location.hash = `#/session/${sessionId}/done`;
                return;
            }
            renderRoom(fresh, me);
        };
        currentOnSocketFinalized = () => {
            window.location.hash = `#/session/${sessionId}/done`;
        };
        SliceSocket.on('session:update',    currentOnSocketUpdate);
        SliceSocket.on('session:finalized', currentOnSocketFinalized);

        function renderRoom(s, meData) {
            const node = SliceViews.renderSession(s, meData.participant_id, meData.name);
            mount(node);
            wireRoom(node, s, meData);
        }
    }

    function wireRoom(node, session, me) {
        // ---- share link ---- //
        node.querySelector('#btn-copy-link').addEventListener('click', async () => {
            const url = `${window.location.origin}/#/session/${session.id}`;
            try {
                await navigator.clipboard.writeText(url);
                toast('Share link copied');
            } catch {
                prompt('Copy this link:', url);
            }
        });

        // ---- single-qty checkboxes ---- //
        node.querySelectorAll('[data-item-check]').forEach(cb => {
            cb.addEventListener('change', async () => {
                const itemId = cb.getAttribute('data-item-id');
                const qty = cb.checked ? 1 : 0;
                await setSelectionWithGuard(session.id, me.participant_id, itemId, qty);
            });
        });

        // ---- multi-qty ± controls ---- //
        node.querySelectorAll('[data-item-qty]').forEach(wrap => {
            const itemId = wrap.getAttribute('data-item-id');
            const max = parseInt(wrap.getAttribute('data-max'), 10);
            const valEl = wrap.querySelector('[data-qty-val]');

            wrap.querySelector('[data-qty-dec]').addEventListener('click', async () => {
                const cur = parseInt(valEl.textContent, 10);
                const next = Math.max(0, cur - 1);
                if (next === cur) return;
                await setSelectionWithGuard(session.id, me.participant_id, itemId, next);
            });
            wrap.querySelector('[data-qty-inc]').addEventListener('click', async () => {
                const cur = parseInt(valEl.textContent, 10);
                const next = Math.min(max, cur + 1);
                if (next === cur) return;
                await setSelectionWithGuard(session.id, me.participant_id, itemId, next);
            });
        });

        // ---- submit / unsubmit ---- //
        const submit = node.querySelector('#btn-submit');
        if (submit) submit.addEventListener('click', async () => {
            try {
                await SliceAPI.submitShare(session.id, me.participant_id);
                toast('Share submitted — thanks!');
            } catch (e) { toast(e.message, 'error'); }
        });
        const unsubmit = node.querySelector('#btn-unsubmit');
        if (unsubmit) unsubmit.addEventListener('click', async () => {
            try { await SliceAPI.unsubmitShare(session.id, me.participant_id); }
            catch (e) { toast(e.message, 'error'); }
        });

        // ---- finalize (host only) ---- //
        const fin = node.querySelector('#btn-finalize');
        if (fin) fin.addEventListener('click', async () => {
            if (!confirm('Finalize the bill? Nobody will be able to change their selections after this.')) return;
            try {
                await SliceAPI.finalize(session.id, me.participant_id);
                // server will push `session:finalized` — we'll navigate there.
            } catch (e) { toast(e.message, 'error'); }
        });
    }

    async function setSelectionWithGuard(sessionId, participantId, itemId, qty) {
        try {
            await SliceAPI.setSelection(sessionId, participantId, itemId, qty);
        } catch (e) {
            // Surface the server's validation error; socket update will revert UI.
            toast(e.message, 'error');
        }
    }

    // =================================================================
    //  VIEW: RESULTS
    // =================================================================
    async function showResults(sessionId) {
        mount(SliceViews.renderLoading('Doing the math…'));
        const me = storage.getMe(sessionId);
        let results;
        try { results = await SliceAPI.getResults(sessionId); }
        catch (e) { mount(SliceViews.renderError(e)); return; }

        const node = SliceViews.renderResults(results, me ? me.participant_id : null);
        mount(node);

        node.querySelector('#btn-copy-summary').addEventListener('click', async () => {
            const lines = [
                `${results.merchant || 'Bill'} — ${results.n_participants} people — total ${money(results.grand_total)}`,
                '',
                ...results.summaries.map(s =>
                    `${s.name}: food ${money(s.food_subtotal)} + fees ${money(s.fee_share)} = ${money(s.total_owed)}`),
                '',
                ...(results.settlements || []).map(s =>
                    `${s.from_name} owes ${s.to_name} ${money(s.amount)}`),
            ];
            const text = lines.join('\n');
            try { await navigator.clipboard.writeText(text); toast('Summary copied to clipboard'); }
            catch { prompt('Copy manually:', text); }
        });
    }

    function money(v) {
        return (v == null ? 0 : Number(v))
            .toLocaleString(undefined, { style: 'currency', currency: 'USD' });
    }

    // ---------------- BOOT ---------------- //
    route();
})();
