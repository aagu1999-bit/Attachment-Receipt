/* ---------------------------------------------------------------- *
 *  views.js — pure render functions. Each returns an HTMLElement.
 *  Event wiring lives in app.js to keep templates declarative.
 * ---------------------------------------------------------------- */

(function () {
    'use strict';

    // -- utilities --
    const $ = (html) => {
        const t = document.createElement('template');
        t.innerHTML = html.trim();
        return t.content.firstElementChild;
    };
    const money = (v) =>
        (v == null ? 0 : Number(v)).toLocaleString(undefined, { style: 'currency', currency: 'USD' });
    const esc = (s) =>
        String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');

    // ================================================================
    //  LANDING
    // ================================================================
    function renderHome() {
        return $(`
        <section class="view-enter">
          <div class="grid md:grid-cols-12 gap-8 items-end">
            <div class="md:col-span-8">
              <p class="page-marker mb-3">№ 01 — the premise</p>
              <h1 class="font-display font-black leading-[0.95] text-[clamp(2.6rem,6vw,4.8rem)] tracking-tight">
                Split the check <span class="italic text-rust">properly.</span>
              </h1>
              <p class="mt-6 text-lg text-ink/70 max-w-xl">
                You paid for dinner. Now you're squinting at a receipt doing mental math while the
                group chat argues about who had the extra beer. Slice fixes that. Upload the receipt,
                share a link, everyone taps what they ate.
              </p>
              <div class="mt-8 flex gap-3 flex-wrap">
                <button id="btn-start" class="btn btn--accent">Start a new receipt →</button>
                <button id="btn-join"  class="btn btn--ghost">I was sent a link</button>
              </div>
            </div>

            <aside class="md:col-span-4 card p-6">
              <p class="page-marker mb-4">the math, briefly</p>
              <dl class="space-y-3 font-mono text-sm">
                <div><dt class="text-smoke">food_p</dt>
                  <dd>Σ (qty × unit_price) for items you picked</dd></div>
                <div><dt class="text-smoke">fees_pp</dt>
                  <dd>(tax + tip + fees) ÷ N people</dd></div>
                <div class="pt-2 border-t border-ink/10">
                  <dt class="text-smoke">total_p</dt>
                  <dd class="font-semibold">food_p + fees_pp</dd></div>
              </dl>
            </aside>
          </div>

          <div id="join-form" class="mt-10 hidden card p-6 max-w-lg view-enter">
            <label class="page-marker mb-2 block">join an existing session</label>
            <div class="flex gap-3">
              <input id="join-code" placeholder="session id (from the link)" class="flex-1 rounded-md border border-ink/15 bg-paper px-3 py-2" />
              <button id="btn-join-go" class="btn btn--primary">Go</button>
            </div>
          </div>
        </section>`);
    }

    // ================================================================
    //  HOST — NAME ENTRY (step 1)
    // ================================================================
    function renderHostStart() {
        return $(`
        <section class="view-enter max-w-xl">
          <p class="page-marker mb-3">№ 02 — you're the host</p>
          <h1 class="font-display font-bold text-4xl mb-6">First — what should people call you?</h1>
          <div class="card p-6 space-y-4">
            <div class="field">
              <label for="host-name">Your name</label>
              <input id="host-name" placeholder="e.g. Alex" maxlength="80" autocomplete="off" />
            </div>
            <p class="text-xs text-smoke">
              We'll assume you're the payer (the person whose card went down).
              You can hand that off later if you want.
            </p>
            <div class="flex gap-3 pt-2">
              <a href="#/" data-link class="btn btn--ghost">← back</a>
              <button id="host-continue" class="btn btn--primary">Continue →</button>
            </div>
          </div>
        </section>`);
    }

    // ================================================================
    //  HOST — UPLOAD (step 2)
    // ================================================================
    function renderHostUpload(sessionId) {
        return $(`
        <section class="view-enter max-w-2xl">
          <p class="page-marker mb-3">№ 03 — the receipt</p>
          <h1 class="font-display font-bold text-4xl mb-2">Upload your receipt</h1>
          <p class="text-ink/60 mb-6">A clear, flat photo works best. We'll parse the items automatically.</p>

          <div id="dropzone" class="dropzone">
            <input id="file-input" type="file" accept="image/*" class="hidden" />
            <div>
              <div class="font-display text-5xl mb-2">📷</div>
              <p class="font-medium">Tap to upload or drop a photo here</p>
              <p class="text-xs text-smoke mt-1">JPG or PNG, up to ~10MB</p>
            </div>
          </div>

          <div id="upload-status" class="mt-4 text-sm text-smoke"></div>
          <p class="text-xs text-smoke mt-6 font-mono">session · ${esc(sessionId)}</p>
        </section>`);
    }

    // ================================================================
    //  HOST — REVIEW (step 3)
    // ================================================================
    function renderHostReview(parsed, sessionId) {
        const items = (parsed.items || []).map((it, i) => `
          <div class="grid grid-cols-12 gap-2 items-center py-2 border-b border-ink/10" data-item-row data-idx="${i}">
            <input class="col-span-6 bg-paper border border-ink/15 rounded px-2 py-1.5 text-sm" data-field="name" value="${esc(it.name)}" />
            <input class="col-span-2 bg-paper border border-ink/15 rounded px-2 py-1.5 text-sm font-mono" data-field="unit_price" type="number" step="0.01" min="0" value="${Number(it.unit_price).toFixed(2)}" />
            <input class="col-span-2 bg-paper border border-ink/15 rounded px-2 py-1.5 text-sm font-mono" data-field="quantity"   type="number" step="1"    min="1" value="${it.quantity}" />
            <button class="col-span-2 text-xs text-rust hover:underline justify-self-end" data-remove>remove</button>
          </div>`).join('');

        return $(`
        <section class="view-enter">
          <p class="page-marker mb-3">№ 04 — review & edit</p>
          <h1 class="font-display font-bold text-4xl mb-2">Does this look right?</h1>
          <p class="text-ink/60 mb-6">
            ${parsed.merchant ? `Parsed from <em class="font-display">${esc(parsed.merchant)}</em>. ` : ''}
            Click any value to correct it.
          </p>

          <div class="card p-6 mb-6">
            <div class="field mb-4">
              <label for="merchant">Merchant</label>
              <input id="merchant" value="${esc(parsed.merchant || '')}" />
            </div>

            <div class="grid grid-cols-12 gap-2 text-xs uppercase tracking-[0.15em] text-smoke pb-2 border-b border-ink/15">
              <span class="col-span-6">Item</span>
              <span class="col-span-2 font-mono">Unit $</span>
              <span class="col-span-2 font-mono">Qty</span>
              <span class="col-span-2 text-right">·</span>
            </div>

            <div id="items-list">${items}</div>

            <button id="add-item" class="mt-3 text-sm text-rust hover:underline">+ add missing item</button>
          </div>

          <div class="grid grid-cols-3 gap-4 mb-8">
            <div class="field"><label>Tax</label>
              <input id="tax"  type="number" step="0.01" min="0" value="${Number(parsed.tax  || 0).toFixed(2)}" /></div>
            <div class="field"><label>Tip</label>
              <input id="tip"  type="number" step="0.01" min="0" value="${Number(parsed.tip  || 0).toFixed(2)}" /></div>
            <div class="field"><label>Fees</label>
              <input id="fees" type="number" step="0.01" min="0" value="${Number(parsed.fees || 0).toFixed(2)}" /></div>
          </div>

          <div class="flex flex-wrap items-center gap-4 justify-between">
            <div class="text-sm text-smoke">
              <span>Subtotal <span id="subtotal-out" class="font-mono text-ink">$0.00</span></span>
              <span class="mx-2">·</span>
              <span>Total <span id="total-out" class="font-mono text-ink font-semibold">$0.00</span></span>
            </div>
            <button id="start-session" class="btn btn--accent">Start collaborative session →</button>
          </div>
        </section>`);
    }

    // ================================================================
    //  SESSION — the live item-picking room
    // ================================================================
    function renderSession(session, meId, meName) {
        const isHost = session.host_participant_id === meId;
        const me = session.participants.find(p => p.id === meId);
        const allSubmitted = session.participants.length > 0 && session.participants.every(p => p.submitted);

        const participantsHtml = session.participants.map(p => {
            const cls = [
                'chip',
                p.is_host ? 'chip--host' : '',
                p.submitted ? 'chip--submitted' : '',
            ].filter(Boolean).join(' ');
            const you = p.id === meId ? ' (you)' : '';
            const host = p.is_host ? ' · host' : '';
            return `<span class="${cls}">${esc(p.name)}${you}${host}</span>`;
        }).join('');

        const itemsHtml = session.items.map(it => renderItemRow(it, session, meId)).join('');

        const hostControls = isHost ? `
          <div class="mt-8 card p-6 border-ink/30">
            <div class="flex items-center justify-between gap-4 flex-wrap">
              <div>
                <p class="page-marker">host controls</p>
                <p class="text-sm text-ink/70 mt-1">
                  ${allSubmitted
                    ? "Everyone's in. Lock it up and do the math."
                    : "Waiting for everyone to submit. You can finalize anytime."}
                </p>
              </div>
              <button id="btn-finalize" class="btn btn--accent">Finalize bill →</button>
            </div>
          </div>` : '';

        const submitBtn = (me && me.submitted)
          ? `<button id="btn-unsubmit" class="btn btn--ghost">Undo submit</button>`
          : `<button id="btn-submit"   class="btn btn--primary">Submit my share →</button>`;

        return $(`
        <section class="view-enter">
          <div class="flex items-start justify-between flex-wrap gap-4 mb-6">
            <div>
              <p class="page-marker mb-1">${esc(session.merchant || 'Your bill')}</p>
              <h1 class="font-display font-bold text-3xl sm:text-4xl">What did you order, ${esc(meName)}?</h1>
            </div>
            <button id="btn-copy-link" class="btn btn--ghost" title="Copy share link">
              <span>🔗</span> share link
            </button>
          </div>

          <div class="flex flex-wrap gap-2 mb-8">${participantsHtml}</div>

          <div class="card overflow-hidden">
            <div class="px-5 py-3 border-b border-ink/10 flex items-center justify-between">
              <span class="page-marker">menu · tap to claim</span>
              <span class="text-xs text-smoke font-mono">items × qty</span>
            </div>
            <div id="items-list">${itemsHtml}</div>
            <div class="receipt-sep mx-5"></div>
            <div class="px-5 pb-4 grid grid-cols-3 gap-4 text-sm font-mono">
              <div><div class="text-smoke text-xs uppercase tracking-[0.15em]">Tax</div>${money(session.tax)}</div>
              <div><div class="text-smoke text-xs uppercase tracking-[0.15em]">Tip</div>${money(session.tip)}</div>
              <div><div class="text-smoke text-xs uppercase tracking-[0.15em]">Fees</div>${money(session.fees)}</div>
            </div>
          </div>

          <div class="mt-6 flex items-center justify-between gap-4 flex-wrap">
            <p class="text-sm text-smoke">
              Fees split evenly across <span class="font-mono">${session.participants.length}</span> ${session.participants.length === 1 ? 'person' : 'people'}.
            </p>
            ${submitBtn}
          </div>

          ${hostControls}
        </section>`);
    }

    function renderItemRow(it, session, meId) {
        const mySelection = (it.selections || []).find(s => s.participant_id === meId);
        const myQty = mySelection ? mySelection.quantity : 0;
        const claimedByOthers = (it.selections || [])
            .filter(s => s.participant_id !== meId)
            .reduce((a, s) => a + s.quantity, 0);
        const remaining = Math.max(0, it.quantity - claimedByOthers - myQty);

        // Who-has-what line
        const others = (it.selections || []).filter(s => s.quantity > 0).map(s => {
            const person = session.participants.find(p => p.id === s.participant_id);
            if (!person) return '';
            const label = person.id === meId ? 'you' : person.name;
            return `${esc(label)}${s.quantity > 1 ? ` × ${s.quantity}` : ''}`;
        }).filter(Boolean).join(' · ') || 'no claims yet';

        let pillClass = 'claimed-pill';
        if (claimedByOthers + myQty === 0) pillClass += ' claimed-pill--empty';
        if (remaining === 0) pillClass += ' claimed-pill--full';

        const totalClaimed = claimedByOthers + myQty;
        const pillText = `${totalClaimed}/${it.quantity} claimed`;

        let control;
        if (it.quantity === 1) {
            const checked = myQty === 1 ? 'checked' : '';
            const disabled = (myQty === 0 && remaining === 0) ? 'disabled' : '';
            control = `
              <label class="inline-flex items-center gap-2 cursor-pointer select-none ${disabled ? 'opacity-40' : ''}">
                <input type="checkbox" ${checked} ${disabled}
                       data-item-check data-item-id="${esc(it.id)}"
                       class="w-5 h-5 accent-rust" />
                <span class="text-xs uppercase tracking-[0.15em] text-smoke">mine</span>
              </label>`;
        } else {
            const maxAllowed = myQty + remaining;
            control = `
              <div class="qty" data-item-qty data-item-id="${esc(it.id)}" data-max="${maxAllowed}">
                <button data-qty-dec ${myQty === 0 ? 'disabled' : ''}>−</button>
                <span class="qty-val" data-qty-val>${myQty}</span>
                <button data-qty-inc ${myQty >= maxAllowed ? 'disabled' : ''}>+</button>
              </div>`;
        }

        return `
          <div class="item-row">
            <div>
              <div class="item-name">${esc(it.name)}</div>
              <div class="item-meta">
                ${money(it.unit_price)}${it.quantity > 1 ? ` · qty ${it.quantity}` : ''}
                <span class="mx-1">·</span>
                <span class="${pillClass}">${pillText}</span>
              </div>
              <div class="text-xs text-smoke mt-1">${others}</div>
            </div>
            <div class="flex items-center gap-3">
              <div class="item-price">${money(it.unit_price * it.quantity)}</div>
              ${control}
            </div>
          </div>`;
    }

    // ================================================================
    //  RESULTS
    // ================================================================
    function renderResults(results, meId) {
        const head = `
          <div class="result-row result-row--head">
            <span>Name</span>
            <span class="text-right">Food</span>
            <span class="text-right">Fees</span>
            <span class="text-right">Total</span>
            <span class="text-right">Note</span>
          </div>`;

        const rows = results.summaries.map(s => {
            const note = s.participant_id === meId ? 'you' : '';
            return `
              <div class="result-row">
                <span class="font-display text-lg">${esc(s.name)}</span>
                <span class="result-amt"><span class="result-amt-label">Food</span>${money(s.food_subtotal)}</span>
                <span class="result-amt"><span class="result-amt-label">Fees</span>${money(s.fee_share)}</span>
                <span class="result-amt font-semibold"><span class="result-amt-label">Total</span>${money(s.total_owed)}</span>
                <span class="result-amt text-smoke text-sm">${note}</span>
              </div>`;
        }).join('');

        const settlements = (results.settlements || []).length
            ? results.settlements.map(s =>
                `<li class="py-2 border-b border-ink/10 last:border-none flex items-center justify-between gap-4">
                   <span><span class="font-display font-semibold">${esc(s.from_name)}</span>
                     <span class="text-smoke"> owes </span>
                     <span class="font-display font-semibold">${esc(s.to_name)}</span></span>
                   <span class="font-mono text-rust font-semibold">${money(s.amount)}</span>
                 </li>`).join('')
            : `<li class="py-3 text-smoke">No one owes anything. Nice.</li>`;

        return $(`
        <section class="view-enter">
          <p class="page-marker mb-3">№ 05 — the reckoning</p>
          <h1 class="font-display font-bold text-4xl mb-2">${esc(results.merchant || 'Your bill')}</h1>
          <p class="text-ink/60 mb-8">
            ${results.n_participants} ${results.n_participants === 1 ? 'person' : 'people'} ·
            grand total <span class="font-mono text-ink font-semibold">${money(results.grand_total)}</span>
          </p>

          <div class="card overflow-hidden mb-8">
            ${head}
            ${rows || '<div class="p-6 text-smoke">No participants.</div>'}
          </div>

          <div class="card p-6">
            <p class="page-marker mb-3">settle up</p>
            <ul class="divide-y-0">${settlements}</ul>
          </div>

          <div class="mt-8 flex gap-3">
            <a href="#/" data-link class="btn btn--ghost">← back to home</a>
            <button id="btn-copy-summary" class="btn btn--primary">Copy summary</button>
          </div>
        </section>`);
    }

    // ================================================================
    //  JOIN (non-host landing)
    // ================================================================
    function renderJoin(sessionId, session) {
        return $(`
        <section class="view-enter max-w-xl">
          <p class="page-marker mb-3">you were invited</p>
          <h1 class="font-display font-bold text-4xl mb-2">
            Join ${esc(session && session.merchant ? session.merchant : 'this bill')}
          </h1>
          <p class="text-ink/60 mb-6">${session
              ? `${session.participants.length} ${session.participants.length === 1 ? 'person is' : 'people are'} already inside.`
              : ''}</p>

          <div class="card p-6 space-y-4">
            <div class="field">
              <label>Your name</label>
              <input id="join-name" placeholder="what should we call you?" maxlength="80" />
            </div>
            <button id="join-continue" class="btn btn--primary">Join →</button>
          </div>
          <p class="text-xs text-smoke mt-4 font-mono">session · ${esc(sessionId)}</p>
        </section>`);
    }

    // ================================================================
    //  MISC
    // ================================================================
    function renderLoading(msg) {
        return $(`
          <section class="view-enter text-center py-20">
            <span class="spinner"></span>
            <p class="mt-4 text-smoke">${esc(msg || 'Loading…')}</p>
          </section>`);
    }

    function renderError(err) {
        return $(`
          <section class="view-enter max-w-lg">
            <p class="page-marker mb-3">something broke</p>
            <h1 class="font-display font-bold text-3xl mb-4">${esc(err.message || 'Unknown error')}</h1>
            <a href="#/" data-link class="btn btn--ghost">← back home</a>
          </section>`);
    }

    function renderWaitingForHost(session) {
        return $(`
          <section class="view-enter text-center py-20">
            <p class="page-marker mb-3">standby</p>
            <h1 class="font-display font-bold text-3xl mb-3">The host is still setting up the receipt…</h1>
            <p class="text-smoke">We'll drop you in automatically when it's ready.</p>
            <div class="mt-6"><span class="spinner"></span></div>
            <p class="text-xs text-smoke mt-8 font-mono">session · ${esc(session.id)}</p>
          </section>`);
    }

    window.SliceViews = {
        renderHome,
        renderHostStart,
        renderHostUpload,
        renderHostReview,
        renderSession,
        renderResults,
        renderJoin,
        renderLoading,
        renderError,
        renderWaitingForHost,
        _utils: { money, esc },
    };
})();
