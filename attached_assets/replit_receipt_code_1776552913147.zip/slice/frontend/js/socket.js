/* ---------------------------------------------------------------- *
 *  socket.js — wraps the Socket.IO client for Slice.
 *  Exposes window.SliceSocket:
 *      connect(sessionId, participantId)
 *      on(event, handler)  // 'session:update', 'session:finalized'
 *      disconnect()
 * ---------------------------------------------------------------- */

(function () {
    'use strict';

    let socket = null;
    const listeners = { 'session:update': [], 'session:finalized': [] };

    function fire(event, payload) {
        (listeners[event] || []).forEach(cb => {
            try { cb(payload); } catch (e) { console.error(e); }
        });
    }

    const SliceSocket = {
        connect(sessionId, participantId) {
            // Disconnect any stale socket before opening a fresh one.
            if (socket) {
                try { socket.disconnect(); } catch (_) { /* noop */ }
                socket = null;
            }

            socket = io({ path: '/socket.io', transports: ['websocket', 'polling'] });

            socket.on('connect', () => {
                socket.emit('join', { session_id: sessionId, participant_id: participantId });
            });

            socket.on('session:update',    (payload) => fire('session:update', payload));
            socket.on('session:finalized', (payload) => fire('session:finalized', payload));

            socket.on('disconnect', () => { /* auto-reconnect is built-in */ });
        },

        on(event, cb) {
            if (!listeners[event]) listeners[event] = [];
            listeners[event].push(cb);
        },

        off(event, cb) {
            if (!listeners[event]) return;
            listeners[event] = listeners[event].filter(fn => fn !== cb);
        },

        disconnect() {
            if (socket) socket.disconnect();
            socket = null;
        },
    };

    window.SliceSocket = SliceSocket;
})();
