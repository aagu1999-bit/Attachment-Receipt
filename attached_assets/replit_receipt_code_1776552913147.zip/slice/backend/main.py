"""
main.py
-------
Slice — collaborative bill-splitting app.

Stack:
    FastAPI            HTTP + static file server
    python-socketio    Real-time selection sync (ASGI-mounted)
    SQLite             Persistence via the `database` module
    Mindee / Veryfi    OCR (pluggable, see ocr_service.py)

Run (dev):
    cd backend
    pip install -r requirements.txt
    cp .env.example .env     # fill in MINDEE_API_KEY
    uvicorn main:socket_app --reload --host 0.0.0.0 --port 8000

The frontend SPA is served at /, API lives at /api/*, Socket.IO at /socket.io/.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import socketio
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from calculator import (can_select, dollars_to_cents, split_bill)
from database import get_db, init_db, new_id
from models import (CreateSessionRequest, FinalResults, JoinSessionRequest,
                    ReviewReceiptRequest, SelectItemRequest, SessionOut)
from ocr_service import parse_receipt

load_dotenv()

# --------------------------------------------------------------------------- #
#  App & Socket.IO bootstrap
# --------------------------------------------------------------------------- #

app = FastAPI(title="Slice API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # dev-friendly; tighten in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

sio = socketio.AsyncServer(
    async_mode="asgi",
    cors_allowed_origins="*",
    logger=False,
    engineio_logger=False,
)

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


@app.on_event("startup")
async def _on_startup() -> None:
    init_db()


# --------------------------------------------------------------------------- #
#  Helpers: hydrate a session into the API response shape
# --------------------------------------------------------------------------- #


def _cents_to_dollars(c: int) -> float:
    return round((c or 0) / 100.0, 2)


def _load_session(session_id: str) -> Dict[str, Any]:
    """
    Pull a session and everything attached to it. Raises 404 if missing.
    Returned shape matches `SessionOut`.
    """
    with get_db() as db:
        s = db.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not s:
            raise HTTPException(status_code=404, detail="Session not found")

        participants = db.execute(
            "SELECT * FROM participants WHERE session_id = ? ORDER BY joined_at ASC",
            (session_id,),
        ).fetchall()

        items = db.execute(
            "SELECT * FROM receipt_items WHERE session_id = ? ORDER BY position ASC",
            (session_id,),
        ).fetchall()

        selections = db.execute(
            "SELECT * FROM selections WHERE session_id = ?",
            (session_id,),
        ).fetchall()

    # selections indexed by item for quick "remaining" calculation
    sel_by_item: Dict[str, List[Dict]] = {}
    for sel in selections:
        sel_by_item.setdefault(sel["item_id"], []).append({
            "participant_id": sel["participant_id"],
            "quantity":       sel["quantity"],
        })

    item_out = []
    for it in items:
        claimed = sum(x["quantity"] for x in sel_by_item.get(it["id"], []))
        item_out.append({
            "id":         it["id"],
            "name":       it["name"],
            "unit_price": _cents_to_dollars(it["unit_price_cents"]),
            "quantity":   it["quantity"],
            "remaining":  max(0, it["quantity"] - claimed),
            "selections": sel_by_item.get(it["id"], []),
        })

    return {
        "id":                   s["id"],
        "merchant":             s["merchant"],
        "status":               s["status"],
        "host_participant_id":  s["host_participant_id"],
        "tax":                  _cents_to_dollars(s["tax_cents"]),
        "tip":                  _cents_to_dollars(s["tip_cents"]),
        "fees":                 _cents_to_dollars(s["fees_cents"]),
        "participants": [
            {
                "id":        p["id"],
                "name":      p["name"],
                "is_host":   bool(p["is_host"]),
                "submitted": bool(p["submitted"]),
            }
            for p in participants
        ],
        "items": item_out,
    }


async def _broadcast_session(session_id: str) -> None:
    """Push the current canonical state to every socket in the room."""
    payload = _load_session(session_id)
    await sio.emit("session:update", payload, room=session_id)


# --------------------------------------------------------------------------- #
#  REST endpoints — session lifecycle
# --------------------------------------------------------------------------- #


@app.post("/api/sessions")
async def create_session(body: CreateSessionRequest) -> Dict[str, str]:
    """
    Create a new session (status='draft') and register the host as its first
    participant. Returns IDs the client persists in localStorage.
    """
    session_id = new_id()
    host_id = new_id()

    with get_db() as db:
        db.execute(
            "INSERT INTO sessions (id, host_participant_id, status) VALUES (?, ?, 'draft')",
            (session_id, host_id),
        )
        db.execute(
            "INSERT INTO participants (id, session_id, name, is_host) VALUES (?, ?, ?, 1)",
            (host_id, session_id, body.host_name.strip()),
        )
    return {"session_id": session_id, "participant_id": host_id}


@app.post("/api/sessions/{session_id}/upload")
async def upload_receipt(session_id: str, file: UploadFile = File(...)) -> Dict[str, Any]:
    """
    OCR the uploaded image. Does NOT persist anything yet — host edits first,
    then POSTs /review with the final values.
    """
    with get_db() as db:
        row = db.execute("SELECT status FROM sessions WHERE id = ?", (session_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Session not found")
    if row["status"] != "draft":
        raise HTTPException(status_code=400, detail="Session already started")

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Empty upload")

    try:
        parsed = await parse_receipt(data, filename=file.filename or "receipt.jpg")
    except Exception as exc:  # noqa: BLE001
        # Surface a helpful error; host can still edit the (blank) result.
        raise HTTPException(status_code=502, detail=f"OCR failed: {exc}")

    return parsed


@app.post("/api/sessions/{session_id}/review")
async def review_receipt(session_id: str, body: ReviewReceiptRequest) -> SessionOut:
    """
    Persist the host-reviewed receipt and flip status to 'open' so friends can
    join and start selecting.
    """
    with get_db() as db:
        row = db.execute("SELECT status FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Session not found")
        if row["status"] == "finalized":
            raise HTTPException(status_code=400, detail="Session already finalized")

        # Wipe any previous items (idempotent re-review).
        db.execute("DELETE FROM selections WHERE session_id = ?", (session_id,))
        db.execute("DELETE FROM receipt_items WHERE session_id = ?", (session_id,))

        for idx, item in enumerate(body.items):
            db.execute(
                """INSERT INTO receipt_items
                       (id, session_id, name, unit_price_cents, quantity, position)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    item.id or new_id(),
                    session_id,
                    item.name,
                    dollars_to_cents(item.unit_price),
                    int(item.quantity),
                    idx,
                ),
            )

        db.execute(
            """UPDATE sessions
               SET merchant = ?, tax_cents = ?, tip_cents = ?, fees_cents = ?, status = 'open'
               WHERE id = ?""",
            (
                body.merchant.strip(),
                dollars_to_cents(body.tax),
                dollars_to_cents(body.tip),
                dollars_to_cents(body.fees),
                session_id,
            ),
        )

    payload = _load_session(session_id)
    await _broadcast_session(session_id)
    return payload  # FastAPI will coerce dict -> SessionOut


@app.get("/api/sessions/{session_id}")
async def get_session(session_id: str) -> SessionOut:
    return _load_session(session_id)


@app.post("/api/sessions/{session_id}/join")
async def join_session(session_id: str, body: JoinSessionRequest) -> Dict[str, str]:
    """
    A new (non-host) participant joins. Duplicate names are allowed — we
    disambiguate by ID.
    """
    with get_db() as db:
        row = db.execute("SELECT status FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Session not found")
        if row["status"] == "finalized":
            raise HTTPException(status_code=400, detail="Session already finalized")

        pid = new_id()
        db.execute(
            "INSERT INTO participants (id, session_id, name, is_host) VALUES (?, ?, ?, 0)",
            (pid, session_id, body.name.strip()),
        )

    await _broadcast_session(session_id)
    return {"participant_id": pid}


# --------------------------------------------------------------------------- #
#  REST endpoints — selections
# --------------------------------------------------------------------------- #


@app.post("/api/sessions/{session_id}/participants/{participant_id}/select")
async def set_selection(
    session_id: str,
    participant_id: str,
    body: SelectItemRequest,
) -> Dict[str, Any]:
    """
    Create / update / remove (quantity=0) this participant's claim on an item.
    Enforces aggregate-quantity invariant.
    """
    with get_db() as db:
        s = db.execute("SELECT status FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not s:
            raise HTTPException(status_code=404, detail="Session not found")
        if s["status"] != "open":
            raise HTTPException(status_code=400, detail="Session not open for selections")

        participant = db.execute(
            "SELECT id, submitted FROM participants WHERE id = ? AND session_id = ?",
            (participant_id, session_id),
        ).fetchone()
        if not participant:
            raise HTTPException(status_code=404, detail="Participant not in session")
        if participant["submitted"]:
            raise HTTPException(status_code=400, detail="Already submitted your share")

        item = db.execute(
            "SELECT id, quantity FROM receipt_items WHERE id = ? AND session_id = ?",
            (body.item_id, session_id),
        ).fetchone()
        if not item:
            raise HTTPException(status_code=404, detail="Item not found in session")

        existing = db.execute(
            "SELECT participant_id, item_id, quantity FROM selections WHERE session_id = ?",
            (session_id,),
        ).fetchall()
        existing_list = [dict(r) for r in existing]

        if not can_select(
            existing_selections=existing_list,
            participant_id=participant_id,
            item_id=body.item_id,
            requested_qty=body.quantity,
            item_quantity=item["quantity"],
        ):
            raise HTTPException(
                status_code=409,
                detail="Not enough of that item left for this claim",
            )

        if body.quantity == 0:
            db.execute(
                "DELETE FROM selections WHERE participant_id = ? AND item_id = ?",
                (participant_id, body.item_id),
            )
        else:
            # UPSERT pattern (SQLite ≥ 3.24)
            db.execute(
                """INSERT INTO selections (id, session_id, participant_id, item_id, quantity)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(participant_id, item_id)
                   DO UPDATE SET quantity = excluded.quantity""",
                (new_id(), session_id, participant_id, body.item_id, body.quantity),
            )

    await _broadcast_session(session_id)
    return {"ok": True}


@app.post("/api/sessions/{session_id}/participants/{participant_id}/submit")
async def submit_share(session_id: str, participant_id: str) -> Dict[str, Any]:
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM participants WHERE id = ? AND session_id = ?",
            (participant_id, session_id),
        ).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Participant not in session")
        db.execute(
            "UPDATE participants SET submitted = 1 WHERE id = ?", (participant_id,)
        )

    await _broadcast_session(session_id)
    return {"ok": True}


@app.post("/api/sessions/{session_id}/participants/{participant_id}/unsubmit")
async def unsubmit_share(session_id: str, participant_id: str) -> Dict[str, Any]:
    """Allow a friend to un-submit while the session is still open."""
    with get_db() as db:
        s = db.execute("SELECT status FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not s:
            raise HTTPException(status_code=404, detail="Session not found")
        if s["status"] != "open":
            raise HTTPException(status_code=400, detail="Session is not open")
        db.execute(
            "UPDATE participants SET submitted = 0 WHERE id = ? AND session_id = ?",
            (participant_id, session_id),
        )

    await _broadcast_session(session_id)
    return {"ok": True}


# --------------------------------------------------------------------------- #
#  REST endpoints — finalisation
# --------------------------------------------------------------------------- #


@app.post("/api/sessions/{session_id}/finalize")
async def finalize(session_id: str, participant_id: str = Form(...)) -> FinalResults:
    """
    Lock the session and compute the final split. Only the host can call this.
    """
    with get_db() as db:
        s = db.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not s:
            raise HTTPException(status_code=404, detail="Session not found")
        if s["host_participant_id"] != participant_id:
            raise HTTPException(status_code=403, detail="Only the host can finalize")
        if s["status"] == "finalized":
            pass  # idempotent — just return the numbers

        db.execute("UPDATE sessions SET status = 'finalized' WHERE id = ?", (session_id,))

    results = _compute_results(session_id)
    await sio.emit("session:finalized", results, room=session_id)
    await _broadcast_session(session_id)
    return results


@app.get("/api/sessions/{session_id}/results")
async def get_results(session_id: str) -> FinalResults:
    return _compute_results(session_id)


def _compute_results(session_id: str) -> Dict[str, Any]:
    with get_db() as db:
        s = db.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
        if not s:
            raise HTTPException(status_code=404, detail="Session not found")

        participants = db.execute(
            "SELECT * FROM participants WHERE session_id = ? ORDER BY joined_at",
            (session_id,),
        ).fetchall()
        items = db.execute(
            "SELECT * FROM receipt_items WHERE session_id = ?", (session_id,),
        ).fetchall()
        selections = db.execute(
            "SELECT * FROM selections WHERE session_id = ?", (session_id,),
        ).fetchall()

    raw = split_bill(
        participants=[
            {"id": p["id"], "name": p["name"], "is_host": bool(p["is_host"])}
            for p in participants
        ],
        items=[
            {
                "id": it["id"],
                "name": it["name"],
                "unit_price_cents": it["unit_price_cents"],
                "quantity": it["quantity"],
            }
            for it in items
        ],
        selections=[
            {
                "participant_id": sel["participant_id"],
                "item_id":        sel["item_id"],
                "quantity":       sel["quantity"],
            }
            for sel in selections
        ],
        tax_cents=s["tax_cents"],
        tip_cents=s["tip_cents"],
        fees_cents=s["fees_cents"],
    )

    return {
        "session_id":       session_id,
        "merchant":         s["merchant"],
        "n_participants":   raw["n_participants"],
        "fees_total":       _cents_to_dollars(raw["fees_total_cents"]),
        "fees_per_person":  _cents_to_dollars(raw["fees_per_person_cents"]),
        "summaries":        raw["summaries"],
        "settlements":      raw["settlements"],
        "grand_total":      _cents_to_dollars(raw["grand_total_cents"]),
    }


# --------------------------------------------------------------------------- #
#  Socket.IO events
# --------------------------------------------------------------------------- #


@sio.event
async def connect(sid, environ, auth):
    """Client connected — they'll call `join` next with their session id."""
    pass


@sio.event
async def join(sid, data):
    """
    Client joins the Socket.IO "room" for their session so they get broadcasts.
    Payload: { "session_id": "...", "participant_id": "..." }
    """
    session_id = (data or {}).get("session_id")
    if not session_id:
        return {"ok": False, "error": "session_id required"}
    await sio.enter_room(sid, session_id)
    try:
        payload = _load_session(session_id)
    except HTTPException:
        return {"ok": False, "error": "session not found"}
    await sio.emit("session:update", payload, to=sid)
    return {"ok": True}


@sio.event
async def disconnect(sid):
    pass


# --------------------------------------------------------------------------- #
#  Static frontend
# --------------------------------------------------------------------------- #


# Serve CSS & JS under /static, and the SPA shell for every unknown route.
if FRONTEND_DIR.exists():
    app.mount("/css", StaticFiles(directory=FRONTEND_DIR / "css"), name="css")
    app.mount("/js",  StaticFiles(directory=FRONTEND_DIR / "js"),  name="js")

    @app.get("/")
    async def index():
        return FileResponse(FRONTEND_DIR / "index.html")

    @app.get("/{path:path}")
    async def spa_catch_all(path: str):
        # Let API & socket paths 404 normally
        if path.startswith("api") or path.startswith("socket.io"):
            return JSONResponse({"detail": "Not found"}, status_code=404)
        return FileResponse(FRONTEND_DIR / "index.html")


# Socket.IO must wrap FastAPI *after* all routes are registered so the ASGI
# tree is: socketio -> fastapi. Uvicorn serves `socket_app`.
socket_app = socketio.ASGIApp(sio, other_asgi_app=app, socketio_path="socket.io")


if __name__ == "__main__":  # pragma: no cover
    import uvicorn
    uvicorn.run(
        "main:socket_app",
        host=os.environ.get("HOST", "0.0.0.0"),
        port=int(os.environ.get("PORT", "8000")),
        reload=True,
    )
