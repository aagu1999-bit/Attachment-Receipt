"""
ocr_service.py
--------------
Pluggable OCR layer for parsing restaurant receipts.

Supported providers, chosen via `OCR_PROVIDER` env var:
    - "mindee"  : Mindee Receipt API v5   (default, recommended)
    - "veryfi"  : Veryfi Documents API
    - "stub"    : Deterministic fake response useful for local dev / CI

Every provider returns the same normalised dict:

    {
        "merchant":  str,
        "items":     [ {name, unit_price, quantity, line_total}, ... ],
        "tax":       float,      # total tax in dollars
        "tip":       float,      # total gratuity in dollars
        "fees":      float,      # non-food surcharges / admin fees
        "currency":  str,
    }

Drop your API key into .env (see .env.example) and the right adapter is called
automatically. To swap providers, change OCR_PROVIDER only - no call-site edits.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List

import httpx

OCR_PROVIDER = os.environ.get("OCR_PROVIDER", "mindee").lower()
MINDEE_API_KEY = os.environ.get("MINDEE_API_KEY", "")
VERYFI_CLIENT_ID = os.environ.get("VERYFI_CLIENT_ID", "")
VERYFI_API_KEY = os.environ.get("VERYFI_API_KEY", "")
VERYFI_USERNAME = os.environ.get("VERYFI_USERNAME", "")
VERYFI_CLIENT_SECRET = os.environ.get("VERYFI_CLIENT_SECRET", "")


# --------------------------------------------------------------------------- #
#  Public entry point
# --------------------------------------------------------------------------- #


async def parse_receipt(image_bytes: bytes, filename: str = "receipt.jpg") -> Dict[str, Any]:
    """
    Parse a receipt image and return a normalised dict.
    Falls back to the stub if the configured provider has no credentials.
    """
    provider = OCR_PROVIDER

    if provider == "mindee" and MINDEE_API_KEY:
        return await _parse_with_mindee(image_bytes, filename)
    if provider == "veryfi" and VERYFI_CLIENT_ID and VERYFI_API_KEY:
        return await _parse_with_veryfi(image_bytes, filename)

    # No credentials, or explicitly set to stub -> return deterministic fake data.
    return _stub_response()


# --------------------------------------------------------------------------- #
#  Mindee adapter
# --------------------------------------------------------------------------- #


async def _parse_with_mindee(image_bytes: bytes, filename: str) -> Dict[str, Any]:
    """
    Call Mindee's Receipt v5 endpoint and normalise the result.
    Docs: https://developers.mindee.com/docs/receipt-ocr
    """
    url = "https://api.mindee.net/v1/products/mindee/expense_receipts/v5/predict"
    headers = {"Authorization": f"Token {MINDEE_API_KEY}"}

    async with httpx.AsyncClient(timeout=60.0) as client:
        files = {"document": (filename, image_bytes)}
        resp = await client.post(url, headers=headers, files=files)
        resp.raise_for_status()
        payload = resp.json()

    prediction = (
        payload.get("document", {})
        .get("inference", {})
        .get("prediction", {})
    )

    # ---- merchant ---- #
    merchant = (prediction.get("supplier_name") or {}).get("value") or ""

    # ---- line items ---- #
    items: List[Dict[str, Any]] = []
    for li in prediction.get("line_items", []) or []:
        qty = li.get("quantity") or 1
        try:
            qty = max(1, int(round(float(qty))))
        except (TypeError, ValueError):
            qty = 1

        unit_price = li.get("unit_price")
        total_amount = li.get("total_amount") or 0.0
        if unit_price is None and qty:
            unit_price = float(total_amount) / qty if qty else float(total_amount)
        unit_price = float(unit_price or 0.0)

        name = (li.get("description") or "Item").strip() or "Item"
        items.append({
            "name": name,
            "unit_price": round(unit_price, 2),
            "quantity": qty,
            "line_total": round(unit_price * qty, 2),
        })

    # ---- taxes ---- #
    tax = 0.0
    for t in prediction.get("taxes", []) or []:
        try:
            tax += float(t.get("value") or 0.0)
        except (TypeError, ValueError):
            pass

    # ---- tip ---- #
    tip = float((prediction.get("tip") or {}).get("value") or 0.0)

    # ---- currency ---- #
    currency = (prediction.get("locale") or {}).get("currency") or "USD"

    # Mindee doesn't break out "other fees" cleanly; infer as
    #   total - subtotal - tax - tip, clamped to >= 0.
    total = float((prediction.get("total_amount") or {}).get("value") or 0.0)
    subtotal = float((prediction.get("total_net") or {}).get("value") or 0.0)
    if subtotal <= 0:
        subtotal = sum(i["line_total"] for i in items)
    fees = max(0.0, round(total - subtotal - tax - tip, 2))

    return {
        "merchant": merchant,
        "items": items,
        "tax": round(tax, 2),
        "tip": round(tip, 2),
        "fees": fees,
        "currency": currency,
    }


# --------------------------------------------------------------------------- #
#  Veryfi adapter (optional alt)
# --------------------------------------------------------------------------- #


async def _parse_with_veryfi(image_bytes: bytes, filename: str) -> Dict[str, Any]:
    """
    Minimal Veryfi adapter. Veryfi's line-items schema is broadly similar.
    Docs: https://docs.veryfi.com/api/receipts-invoices/process-a-receipt/
    """
    import base64

    url = "https://api.veryfi.com/api/v8/partner/documents/"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "CLIENT-ID": VERYFI_CLIENT_ID,
        "AUTHORIZATION": f"apikey {VERYFI_USERNAME}:{VERYFI_API_KEY}",
    }
    body = {
        "file_name": filename,
        "file_data": base64.b64encode(image_bytes).decode("ascii"),
    }

    async with httpx.AsyncClient(timeout=60.0) as client:
        resp = await client.post(url, headers=headers, json=body)
        resp.raise_for_status()
        data = resp.json()

    items: List[Dict[str, Any]] = []
    for li in data.get("line_items", []) or []:
        qty = int(li.get("quantity") or 1)
        qty = max(1, qty)
        unit_price = float(li.get("price") or 0.0)
        if unit_price == 0 and li.get("total"):
            unit_price = float(li["total"]) / qty
        items.append({
            "name": (li.get("description") or "Item").strip() or "Item",
            "unit_price": round(unit_price, 2),
            "quantity": qty,
            "line_total": round(unit_price * qty, 2),
        })

    return {
        "merchant": data.get("vendor", {}).get("name") or "",
        "items": items,
        "tax": float(data.get("tax") or 0.0),
        "tip": float(data.get("tip") or 0.0),
        "fees": float(data.get("service_fee") or data.get("surcharge") or 0.0),
        "currency": data.get("currency_code") or "USD",
    }


# --------------------------------------------------------------------------- #
#  Stub (dev / demo / CI)
# --------------------------------------------------------------------------- #


def _stub_response() -> Dict[str, Any]:
    """A realistic-looking fake receipt for local development."""
    items = [
        {"name": "Margherita Pizza",  "unit_price": 16.00, "quantity": 1, "line_total": 16.00},
        {"name": "Caesar Salad",      "unit_price": 12.50, "quantity": 1, "line_total": 12.50},
        {"name": "Spaghetti Carbonara","unit_price": 18.00, "quantity": 1, "line_total": 18.00},
        {"name": "Guinness Pint",     "unit_price":  8.00, "quantity": 4, "line_total": 32.00},
        {"name": "Tiramisu",          "unit_price":  9.50, "quantity": 2, "line_total": 19.00},
    ]
    subtotal = sum(i["line_total"] for i in items)
    return {
        "merchant": "La Trattoria",
        "items": items,
        "tax":  round(subtotal * 0.0875, 2),
        "tip":  round(subtotal * 0.18,   2),
        "fees": 3.50,
        "currency": "USD",
    }
