"""
database.py
-----------
SQLite schema and connection helpers for Slice.

Schema overview:
    sessions       - One row per bill-splitting session (created by host)
    participants   - People who joined a session (host + friends)
    receipt_items  - Line items parsed/edited from the receipt
    selections     - Per-participant claims on each item (quantity-aware)

All monetary amounts are stored as INTEGER cents to avoid float drift.
"""

import os
import sqlite3
import uuid
from contextlib import contextmanager
from typing import Iterator

DB_PATH = os.environ.get("DATABASE_PATH", "./slice.db")


SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id              TEXT PRIMARY KEY,          -- UUID used in share URL
    merchant        TEXT NOT NULL DEFAULT '',
    host_participant_id TEXT,                  -- FK participants.id (nullable until host joins)
    tax_cents       INTEGER NOT NULL DEFAULT 0,
    tip_cents       INTEGER NOT NULL DEFAULT 0,
    fees_cents      INTEGER NOT NULL DEFAULT 0,
    status          TEXT NOT NULL DEFAULT 'draft',
                    -- 'draft'     : host still editing parsed OCR
                    -- 'open'      : participants joining / selecting
                    -- 'finalized' : locked, calculation complete
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS participants (
    id            TEXT PRIMARY KEY,           -- UUID
    session_id    TEXT NOT NULL,
    name          TEXT NOT NULL,
    is_host       INTEGER NOT NULL DEFAULT 0,
    submitted     INTEGER NOT NULL DEFAULT 0, -- 1 once they hit "Submit my share"
    joined_at     TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_participants_session ON participants(session_id);

CREATE TABLE IF NOT EXISTS receipt_items (
    id              TEXT PRIMARY KEY,         -- UUID
    session_id      TEXT NOT NULL,
    name            TEXT NOT NULL,
    unit_price_cents INTEGER NOT NULL,        -- price per single unit
    quantity        INTEGER NOT NULL DEFAULT 1,
    position        INTEGER NOT NULL DEFAULT 0, -- display order
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_items_session ON receipt_items(session_id);

CREATE TABLE IF NOT EXISTS selections (
    id              TEXT PRIMARY KEY,         -- UUID
    session_id      TEXT NOT NULL,
    participant_id  TEXT NOT NULL,
    item_id         TEXT NOT NULL,
    quantity        INTEGER NOT NULL,         -- units this participant is claiming
    UNIQUE (participant_id, item_id),
    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES receipt_items(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_selections_session ON selections(session_id);
CREATE INDEX IF NOT EXISTS idx_selections_item ON selections(item_id);
"""


def _connect() -> sqlite3.Connection:
    """Open a SQLite connection with sensible defaults."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def get_db() -> Iterator[sqlite3.Connection]:
    """Context manager yielding a connection; commits on success, rolls back on error."""
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    """Create tables if they don't exist. Safe to call on every startup."""
    with get_db() as conn:
        conn.executescript(SCHEMA)


def new_id() -> str:
    """Generate a short-ish UUID suitable for URLs."""
    return uuid.uuid4().hex[:12]
