"""
models.py
---------
Pydantic request / response schemas for the Slice REST API.

Money is transported over the wire as floating-point *dollars* for readability,
but stored internally as integer *cents*. The helpers `to_cents` / `from_cents`
live in main.py where they're used.
"""

from typing import List, Optional
from pydantic import BaseModel, Field, field_validator


# ------------------------- inbound (request) models ------------------------- #


class CreateSessionRequest(BaseModel):
    host_name: str = Field(..., min_length=1, max_length=80)


class JoinSessionRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)


class ItemInput(BaseModel):
    """Payload shape for creating/updating a single item during host review."""
    id: Optional[str] = None          # absent => new item
    name: str = Field(..., min_length=1, max_length=120)
    unit_price: float = Field(..., ge=0)
    quantity: int = Field(..., ge=1, le=999)

    @field_validator("name")
    @classmethod
    def _strip_name(cls, v: str) -> str:
        return v.strip()


class ReviewReceiptRequest(BaseModel):
    """Host's edits to the OCR output before starting collaboration."""
    merchant: str = Field("", max_length=160)
    tax: float = Field(0.0, ge=0)
    tip: float = Field(0.0, ge=0)
    fees: float = Field(0.0, ge=0)
    items: List[ItemInput]


class SelectItemRequest(BaseModel):
    item_id: str
    quantity: int = Field(..., ge=0, le=999)   # 0 removes the claim


# ------------------------- outbound (response) models ----------------------- #


class ParticipantOut(BaseModel):
    id: str
    name: str
    is_host: bool
    submitted: bool


class SelectionOut(BaseModel):
    participant_id: str
    quantity: int


class ItemOut(BaseModel):
    id: str
    name: str
    unit_price: float
    quantity: int
    remaining: int                        # quantity - sum(selections)
    selections: List[SelectionOut]        # who claimed how many


class SessionOut(BaseModel):
    id: str
    merchant: str
    status: str                           # draft | open | finalized
    host_participant_id: Optional[str]
    tax: float
    tip: float
    fees: float
    participants: List[ParticipantOut]
    items: List[ItemOut]


class PersonSummary(BaseModel):
    participant_id: str
    name: str
    items: List[dict]                     # [{name, qty, line_total}]
    food_subtotal: float
    fee_share: float
    total_owed: float


class Settlement(BaseModel):
    from_name: str
    to_name: str
    amount: float


class FinalResults(BaseModel):
    session_id: str
    merchant: str
    n_participants: int
    fees_total: float
    fees_per_person: float
    summaries: List[PersonSummary]
    settlements: List[Settlement]
    grand_total: float
