"""
calculator.py
-------------
Pure, stateless implementation of the Slice splitting algorithm.

Operates exclusively in INTEGER CENTS to avoid floating-point drift, then
converts to dollars at the boundary.

Algorithm (spec §2, implemented exactly):
    N           = number of unique participants in the session
    fees_total  = tax + tip + other_fees
    fees_pp     = fees_total / N                 (split evenly among everyone)
    food_p      = Σ qty_selected_i * unit_price_i   (per participant)
    total_p     = food_p + fees_pp

A tiny "penny-reconciliation" step redistributes rounding residue so that
Σ total_p equals the true bill total to the cent.

Settlement suggestions are optimised: each non-payer owes the payer directly
(simple star-topology — since one person fronted the card, that's the right
shape; we don't need full graph-minimisation here).
"""

from __future__ import annotations

from typing import Dict, List, TypedDict


class _ItemSpec(TypedDict):
    id: str
    name: str
    unit_price_cents: int
    quantity: int


class _SelectionSpec(TypedDict):
    participant_id: str
    item_id: str
    quantity: int


class _ParticipantSpec(TypedDict):
    id: str
    name: str
    is_host: bool


def split_bill(
    participants: List[_ParticipantSpec],
    items: List[_ItemSpec],
    selections: List[_SelectionSpec],
    tax_cents: int,
    tip_cents: int,
    fees_cents: int,
) -> Dict:
    """
    Run the full split. Returns a dict ready to be serialised into FinalResults.

    Graceful degradation:
        - N == 0  -> no summaries; payload documents the empty state.
        - N == 1  -> the sole participant owes the entire bill (mostly sanity).
    """
    n = len(participants)

    # -------- early exit: nobody is in the session -------- #
    if n == 0:
        return {
            "n_participants": 0,
            "fees_total_cents": tax_cents + tip_cents + fees_cents,
            "fees_per_person_cents": 0,
            "summaries": [],
            "settlements": [],
            "grand_total_cents": 0,
        }

    fees_total_cents = tax_cents + tip_cents + fees_cents

    # Integer division of fees, remainder distributed to first participants for
    # an exact sum. Order is stable so results are deterministic.
    fees_base = fees_total_cents // n
    fees_remainder = fees_total_cents - fees_base * n
    participant_fee_share: Dict[str, int] = {}
    for idx, p in enumerate(participants):
        extra = 1 if idx < fees_remainder else 0  # first `remainder` people pay 1¢ more
        participant_fee_share[p["id"]] = fees_base + extra

    # -------- food cost per participant -------- #
    item_by_id = {it["id"]: it for it in items}
    food_cents: Dict[str, int] = {p["id"]: 0 for p in participants}
    line_records: Dict[str, List[Dict]] = {p["id"]: [] for p in participants}

    for sel in selections:
        if sel["quantity"] <= 0:
            continue
        item = item_by_id.get(sel["item_id"])
        if not item:
            continue
        line_total = sel["quantity"] * item["unit_price_cents"]
        pid = sel["participant_id"]
        if pid not in food_cents:
            continue  # stray selection from a removed participant; skip
        food_cents[pid] += line_total
        line_records[pid].append({
            "item_id":      item["id"],
            "name":         item["name"],
            "quantity":     sel["quantity"],
            "unit_price":   _cents_to_dollars(item["unit_price_cents"]),
            "line_total":   _cents_to_dollars(line_total),
        })

    # -------- compose summaries -------- #
    summaries = []
    grand_total_cents = 0
    name_by_id = {p["id"]: p["name"] for p in participants}

    for p in participants:
        food = food_cents[p["id"]]
        fee_share = participant_fee_share[p["id"]]
        total = food + fee_share
        grand_total_cents += total
        summaries.append({
            "participant_id": p["id"],
            "name":           p["name"],
            "items":          line_records[p["id"]],
            "food_subtotal":  _cents_to_dollars(food),
            "fee_share":      _cents_to_dollars(fee_share),
            "total_owed":     _cents_to_dollars(total),
        })

    # -------- settlement suggestions -------- #
    #
    # Find the host (payer). Every other participant owes the host their total.
    # If the host didn't mark themselves as host, fall back to first participant.
    payer = next((p for p in participants if p["is_host"]), participants[0])
    settlements = []
    for s in summaries:
        if s["participant_id"] == payer["id"]:
            continue
        if s["total_owed"] <= 0:
            continue
        settlements.append({
            "from_name": s["name"],
            "to_name":   payer["name"],
            "amount":    s["total_owed"],
        })

    return {
        "n_participants":        n,
        "fees_total_cents":      fees_total_cents,
        "fees_per_person_cents": fees_base,  # informational; exact shares are in summaries
        "summaries":             summaries,
        "settlements":           settlements,
        "grand_total_cents":     grand_total_cents,
        "payer_name":            payer["name"],
        "payer_id":              payer["id"],
    }


# --------------------------------------------------------------------------- #
#  Validation helper used by the route layer
# --------------------------------------------------------------------------- #


def can_select(
    existing_selections: List[_SelectionSpec],
    participant_id: str,
    item_id: str,
    requested_qty: int,
    item_quantity: int,
) -> bool:
    """
    Check whether setting `participant_id`'s claim on `item_id` to
    `requested_qty` would exceed the available quantity of that item.

    Uses the convention that `existing_selections` includes the caller's
    current claim (which will be overwritten), so we subtract it first.
    """
    if requested_qty < 0 or requested_qty > item_quantity:
        return False

    others_total = 0
    for s in existing_selections:
        if s["item_id"] != item_id:
            continue
        if s["participant_id"] == participant_id:
            continue
        others_total += s["quantity"]

    return others_total + requested_qty <= item_quantity


# --------------------------------------------------------------------------- #
#  Tiny conversion helpers
# --------------------------------------------------------------------------- #


def dollars_to_cents(v: float | int) -> int:
    """Round-half-up to the nearest cent; negatives clamp to 0."""
    if v is None:
        return 0
    cents = int(round(float(v) * 100))
    return max(0, cents)


def _cents_to_dollars(c: int) -> float:
    return round(c / 100.0, 2)
